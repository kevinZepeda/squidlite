import sqlite3
conn  = sqlite3.connect('squidlite.db')
db = conn.cursor()
